const QRCode = require('qrcode');
const promptpay = require('promptpay-qr');

class PromptPayService {
  /**
   * สร้าง PromptPay EMVCo Payload
   * @param {string} promptpayId - เบอร์โทรศัพท์ (เช่น 0812345678) หรือ เลขบัตรประชาชน/Tax ID (13 หลัก)
   * @param {number} amount - ยอดเงินเป็นบาท (ทศนิยม 2 ตำแหน่ง)
   */
  generatePayload(promptpayId, amount) {
    try {
      // ทำความสะอาดเบอร์โทร / เลขประจำตัว
      const cleanId = String(promptpayId || "").replace(/[^0-9]/g, '');
      const numAmount = parseFloat(amount);
      return promptpay(cleanId, { amount: numAmount });
    } catch (err) {
      console.warn("Error using promptpay-qr library, using fallback builder:", err);
      return this.buildFallbackPayload(promptpayId, amount);
    }
  }

  /**
   * สร้าง QR Code Data URL (Base64 PNG) สำหรับแสดงผลบนเว็บทันที
   */
  async generateQRCodeDataURL(promptpayId, amount) {
    const payload = this.generatePayload(promptpayId, amount);
    const dataUrl = await QRCode.toDataURL(payload, {
      errorCorrectionLevel: 'M',
      type: 'image/png',
      margin: 2,
      width: 320,
      color: {
        dark: '#0f172a',
        light: '#ffffff'
      }
    });

    return {
      payload,
      qrDataUrl: dataUrl,
      amount: parseFloat(amount).toFixed(2),
      promptpayId
    };
  }

  // EMVCo PromptPay Fallback generator with CRC-16/CCITT-FALSE
  buildFallbackPayload(id, amount) {
    const clean = String(id).replace(/[^0-9]/g, '');
    let target = clean;
    let targetTag = "01"; // 01 for mobile, 02 for tax ID

    if (clean.length === 10 && clean.startsWith('0')) {
      target = "0066" + clean.substring(1);
      targetTag = "01";
    } else if (clean.length === 13) {
      targetTag = "02";
    }

    const aid = "A000000677010111";
    const sub00 = "00" + String(aid.length).padStart(2, '0') + aid;
    const subTarget = targetTag + String(target.length).padStart(2, '0') + target;
    const tag29Value = sub00 + subTarget;
    const tag29 = "29" + String(tag29Value.length).padStart(2, '0') + tag29Value;

    const formattedAmount = parseFloat(amount).toFixed(2);
    const tag54 = "54" + String(formattedAmount.length).padStart(2, '0') + formattedAmount;

    let payloadWithoutCrc =
      "000201" + // Payload Format Indicator
      "010212" + // Dynamic QR Code
      tag29 +    // Merchant Account Info (PromptPay)
      "5303764" + // Currency THB (764)
      tag54 +    // Transaction Amount
      "5802TH" + // Country Code TH
      "6304";    // CRC placeholder

    const crc = this.crc16(payloadWithoutCrc);
    return payloadWithoutCrc + crc.toUpperCase();
  }

  crc16(data) {
    let crc = 0xFFFF;
    for (let i = 0; i < data.length; i++) {
      let x = ((crc >> 8) ^ data.charCodeAt(i)) & 0xFF;
      x ^= x >> 4;
      crc = ((crc << 8) ^ (x << 12) ^ (x << 5) ^ x) & 0xFFFF;
    }
    return crc.toString(16).padStart(4, '0');
  }
}

module.exports = new PromptPayService();
