class GachaService {
  /**
   * สุ่มการ์ดตามเงื่อนไขของซอง (Pack)
   * @param {Object} pack - ข้อมูลซองการ์ด
   * @param {number} packCount - จำนวนซองที่เปิด (เช่น 1 หรือ 10)
   * @param {Object} userTier - ข้อมูลระดับสมาชิก (เช่น Diamond อาจได้โบนัสเรท SSR +2%)
   */
  rollPacks(pack, packCount = 1, userTier = null) {
    const cardsPerPack = pack.cardsPerPack || 3;
    const totalCardsToRoll = packCount * cardsPerPack;
    const cardPool = pack.cardPool || [];
    
    if (cardPool.length === 0) {
      throw new Error("ไม่มีการ์ดในชุดนี้");
    }

    // คำนวณเรท (Rate modifier ตาม Member Tier)
    const baseRates = { ...(pack.rates || { SSR: 5, SR: 15, R: 30, C: 50 }) };
    
    // โบนัสสิทธิพิเศษ Member Tier
    if (userTier && userTier.id === 'diamond') {
      baseRates.SSR = (baseRates.SSR || 5) + 2; // Diamond VIP ได้เรท SSR เพิ่ม 2%
      baseRates.C = Math.max(10, (baseRates.C || 50) - 2);
    }

    const results = [];
    let hasSRorBetterInTenPull = false;

    for (let i = 0; i < totalCardsToRoll; i++) {
      // Pity rule: ถ้าเป็นการ์ดใบสุดท้ายในการเปิดแบบ 10 ซอง แล้วยังไม่ได้ SR ขึ้นไปเลย จะการันตี SR หรือ SSR
      const isLastCardOfMulti = (packCount >= 5 && i === totalCardsToRoll - 1 && !hasSRorBetterInTenPull);
      
      const rolledCard = this.rollSingleCard(cardPool, baseRates, isLastCardOfMulti);
      if (rolledCard.rarity === 'SSR' || rolledCard.rarity === 'SR') {
        hasSRorBetterInTenPull = true;
      }
      results.push(rolledCard);
    }

    return {
      packId: pack.id,
      packName: pack.name,
      packCount,
      totalCards: results.length,
      cards: results,
      highestRarity: this.getHighestRarity(results)
    };
  }

  rollSingleCard(cardPool, rates, guaranteeSROrBetter = false) {
    const randomPercent = Math.random() * 100;
    let targetRarity = "C";

    if (guaranteeSROrBetter) {
      // 20% โอกาสเป็น SSR, 80% เป็น SR
      targetRarity = Math.random() < 0.25 ? "SSR" : "SR";
    } else {
      const ssrCutoff = rates.SSR;
      const srCutoff = ssrCutoff + rates.SR;
      const rCutoff = srCutoff + rates.R;

      if (randomPercent < ssrCutoff) {
        targetRarity = "SSR";
      } else if (randomPercent < srCutoff) {
        targetRarity = "SR";
      } else if (randomPercent < rCutoff) {
        targetRarity = "R";
      } else {
        targetRarity = "C";
      }
    }

    // กรองการ์ดใน Pool ตาม Rarity ที่สุ่มได้
    let candidates = cardPool.filter(c => c.rarity === targetRarity);
    if (candidates.length === 0) {
      // Fallback หากไม่มีการ์ด rarity นั้น ให้ใช้ทั้งหมด
      candidates = cardPool;
    }

    // สุ่มใบหนึ่งจาก candidates
    const chosen = candidates[Math.floor(Math.random() * candidates.length)];
    
    // คัดลอก Object พร้อมใส่สถานะเอฟเฟกต์การเปิด
    return {
      ...chosen,
      isFoil: chosen.rarity === 'SSR' || (chosen.rarity === 'SR' && Math.random() < 0.4),
      pulledAt: new Date().toISOString()
    };
  }

  getHighestRarity(cards) {
    const rank = { SSR: 4, SR: 3, R: 2, C: 1 };
    let best = "C";
    for (const c of cards) {
      if ((rank[c.rarity] || 0) > (rank[best] || 0)) {
        best = c.rarity;
      }
    }
    return best;
  }
}

module.exports = new GachaService();
